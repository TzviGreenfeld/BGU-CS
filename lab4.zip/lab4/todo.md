# issues:
* 1b:
  - changing output file access
  - truncating output file
* 2a:
  - prefix DONE
